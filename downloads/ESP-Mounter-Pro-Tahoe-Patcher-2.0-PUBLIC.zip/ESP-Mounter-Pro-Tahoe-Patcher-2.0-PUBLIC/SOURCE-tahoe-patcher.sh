The executable shell source used by the patcher is stored inside:
ESP Mounter Pro Tahoe Patcher.app/Contents/MacOS/tahoe-patcher

It is intentionally plain-text shell script so the patch can be inspected before running.
