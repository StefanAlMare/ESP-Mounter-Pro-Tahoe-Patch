ESP Mounter Pro Tahoe Patcher 2.0 — PUBLIC
===========================================

Purpose
-------
Unofficial compatibility patch for ESP Mounter Pro 1.9.1 by Micky1979 on macOS Tahoe 26 (Intel/Hackintosh).

IMPORTANT: This package DOES NOT contain ESP Mounter Pro, its privileged helper, icons, resources, or any other file from the original application.
You must obtain your own original ESP Mounter Pro 1.9.1 copy.

What was wrong
--------------
ESP Mounter Pro was written for the OS X 10.x version-numbering scheme. Its internal version parser reads the second component (objectAtIndex:1).

Example:
  10.13.x -> 13   (works as intended)
  26.6.1  -> 6    (wrong for Tahoe)

On Tahoe this causes the app to select its legacy mount-point path and can make unmounted EFI partitions appear immediately as Unmount/Open.

The fix
-------
The patch changes exactly one byte in the original ESP Mounter Pro 1.9.1 GUI executable:

  File offset: 0xA185 (41349 decimal)
  Original:    41 B8 01 00 00 00
  Patched:     41 B8 00 00 00 00

In practical terms:
  objectAtIndex:1 -> objectAtIndex:0

Tahoe 26.6.1 is then interpreted using major version 26 and ESP Mounter Pro selects its modern disk/mount-point path.

Validated hashes
----------------
Original ESP Mounter Pro 1.9.1 executable SHA-256:
  d6ff190d98ce19334b5e73dd1acf84f1e3b8097e31630080ad76923383eb274c

Tahoe-patched executable SHA-256:
  9d592e051d0f16639042e5ed7920f9ffa3cd8372bdc65aedbd930dda43633e9f

Original ESP Mounter Pro 1.9.1 helper SHA-256:
  359844bce1d9bffefb6b4b106b45c4029fee0869869352a83061cbbb7b198246

What the patcher does
---------------------
1. Runs only on macOS Tahoe 26 on Intel (x86_64).
2. Finds /Applications/ESP Mounter Pro.app or lets you select your original copy.
3. Verifies bundle ID, version 1.9.1, exact executable hash, patch bytes, and exact original helper hash.
4. Creates a complete backup of the original app on your Desktop.
5. Changes the one-byte Tahoe compatibility patch.
6. Removes stale local metadata and ad-hoc signs the modified GUI with macOS codesign.
7. Reinstalls/registers the UNMODIFIED original helper taken from YOUR OWN ESP Mounter Pro bundle.
8. Verifies the patched executable, local app signature, helper hash, root:wheel ownership, mode 0544, and launchd registration.
9. Opens ESP Mounter Pro.

The administrator password is requested once for patch/sign/helper registration. Normal EFI mount/unmount operations then use the helper and do not require the password each time.

Tested
------
Confirmed on macOS Tahoe 26.6.1 (25G76), including EFI partitions on internal disks, USB devices, and external disks. Mount/Open/Unmount operate normally after patching.

How to use
----------
1. Obtain ESP Mounter Pro 1.9.1 yourself from its original distribution source.
2. Put ESP Mounter Pro.app in /Applications (recommended).
3. Open "ESP Mounter Pro Tahoe Patcher.app".
4. Enter the administrator password once when macOS asks.
5. The patcher verifies everything, creates a backup, applies the patch, registers the original helper from your copy, and opens ESP Mounter Pro.

If Gatekeeper blocks this unsigned/unnotarized compatibility patcher after download, use Finder -> right-click the patcher -> Open once.

Restore
-------
Before modifying an original app, the patcher creates a full backup on the Desktop named:
  ESP Mounter Pro - before Tahoe patch YYYYMMDD-HHMMSS.app

To restore, quit ESP Mounter Pro and copy that backup back to /Applications.

Credits / rights
----------------
ESP Mounter Pro © Micky1979. All rights reserved.
This package is an unofficial compatibility patch only. It does not include or redistribute ESP Mounter Pro or its helper.
